# ချစ်ခြင်း ရင်ခုန် (CCYK)

Flutter Android App Project.

## Admin
Password: 2468

## Build
Use Codemagic or GitHub Actions to build:
`flutter build appbundle --release`
