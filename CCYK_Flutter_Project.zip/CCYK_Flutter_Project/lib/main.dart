import 'dart:math';
import 'package:flutter/material.dart';

void main() => runApp(const CCYKApp());

class CCYKApp extends StatelessWidget {
  const CCYKApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ချစ်ခြင်း ရင်ခုန်',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        fontFamily: 'Roboto',
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFFE91E63)),
        useMaterial3: true,
      ),
      home: const HomeShell(),
    );
  }
}

class Profile {
  String id;
  String name;
  int age;
  String country;
  String city;
  String gender;
  String lookingFor;
  String goal;
  String job;
  String education;
  String religion;
  String habit;
  String hobby;
  String about;
  String partner;
  String status;
  int views;
  String facebook;
  String telegram;
  String tiktok;
  String instagram;
  String phone;

  Profile({
    required this.id,
    required this.name,
    required this.age,
    required this.country,
    required this.city,
    required this.gender,
    required this.lookingFor,
    required this.goal,
    this.job = '',
    this.education = '',
    this.religion = '',
    this.habit = '',
    this.hobby = '',
    this.about = '',
    this.partner = '',
    this.status = 'pending',
    this.views = 0,
    this.facebook = '',
    this.telegram = '',
    this.tiktok = '',
    this.instagram = '',
    this.phone = '',
  });
}

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int tab = 0;
  bool isAdmin = false;
  int genCount = 0;

  final profiles = <Profile>[
    Profile(
      id: 'CCYK-1001',
      name: 'မောင်အောင်',
      age: 29,
      country: 'Myanmar',
      city: 'ရန်ကုန်',
      gender: 'ကျား',
      lookingFor: 'မ',
      goal: 'လက်ထပ်ရန်',
      job: 'အင်ဂျင်နီယာ',
      education: 'ဘွဲ့',
      religion: 'ဗုဒ္ဓ',
      habit: 'အရက်၊ ဆေးလိပ် မသုံးပါ',
      hobby: 'မိသားစုဦးစားပေး',
      telegram: 'Telegram: demo',
      status: 'approved',
      about: 'မင်္ဂလာပါ။ ကျွန်တော်က ရန်ကုန်မြို့မှာ နေထိုင်ပြီး အလုပ်ကို တန်ဖိုးထားလုပ်ကိုင်နေသူတစ်ယောက်ပါ။ ရိုးသားမှု၊ ယုံကြည်မှုနဲ့ အပြန်အလှန်လေးစားမှုကို အရေးကြီးတယ်လို့ ယုံကြည်ပါတယ်။ ဘဝကို အေးအေးဆေးဆေးနဲ့ တည်ငြိမ်စွာ တည်ဆောက်ချင်ပြီး မိသားစုကို တန်ဖိုးထားတတ်သူ ဖြစ်ပါတယ်။',
      partner: 'လိုချင်တဲ့ လက်တွဲဖော်က ရိုးသားပြီး တာဝန်ယူတတ်သူ၊ စကားပြောဆိုရာမှာ နားလည်မှုပေးနိုင်သူ ဖြစ်စေချင်ပါတယ်။ မိသားစုကို တန်ဖိုးထားပြီး ဘဝကို အတူတကွ တည်ဆောက်ချင်တဲ့ စိတ်ရှိသူကို ပိုသဘောကျပါတယ်။',
    ),
  ];

  final requests = <String>[];

  void adminLogin() {
    final c = TextEditingController();
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Admin Password'),
        content: TextField(controller: c, obscureText: true),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('ပိတ်မည်')),
          FilledButton(
            onPressed: () {
              if (c.text == '2468') {
                setState(() {
                  isAdmin = true;
                  tab = 3;
                });
                Navigator.pop(context);
              }
            },
            child: const Text('ဝင်မည်'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      homePage(),
      searchPage(),
      postPage(),
      adminPage(),
    ];

    return Scaffold(
      floatingActionButton: FloatingActionButton.small(
        onPressed: adminLogin,
        backgroundColor: Colors.white,
        child: const Text('Admin', style: TextStyle(fontSize: 11)),
      ),
      body: SafeArea(
        child: Column(
          children: [
            header(),
            Expanded(child: pages[tab]),
          ],
        ),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab > 2 ? 0 : tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.search), label: 'Search'),
          NavigationDestination(icon: Icon(Icons.add), label: 'Post'),
        ],
      ),
    );
  }

  Widget header() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(18, 28, 18, 32),
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [Color(0xFF20B8EE), Color(0xFF7867CF), Color(0xFFE91E63)],
        ),
        borderRadius: BorderRadius.only(
          bottomLeft: Radius.circular(34),
          bottomRight: Radius.circular(34),
        ),
      ),
      child: Column(
        children: [
          CustomPaint(size: const Size(170, 82), painter: LogoPainter()),
          const SizedBox(height: 10),
          const Text('ချစ်ခြင်း ရင်ခုန်',
              style: TextStyle(color: Colors.white, fontSize: 34, fontWeight: FontWeight.w900)),
        ],
      ),
    );
  }

  Widget homePage() {
    final approved = profiles.where((p) => p.status == 'approved').toList();
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        appCard(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('ပင်မစာမျက်နှာ', style: title),
            const SizedBox(height: 10),
            const Text('ကိုယ့်အချက်အလက်ဖြည့်လိုက်တာနဲ့ App က Profile စာသားကို မြန်မာလို ရေးပေးပါမယ်။ Contact အချက်အလက်တွေကို Admin ပဲ မြင်နိုင်ပါတယ်။'),
            const SizedBox(height: 12),
            Wrap(spacing: 10, children: [
              FilledButton(onPressed: () => setState(() => tab = 1), child: const Text('လက်တွဲဖော်ရှာရန်')),
              FilledButton.tonal(onPressed: () => setState(() => tab = 2), child: const Text('Profile တင်ရန်')),
            ]),
          ]),
        ),
        appCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Approved Profile များ', style: section),
          ...approved.map(profileCard),
        ])),
      ],
    );
  }

  Widget searchPage() {
    final approved = profiles.where((p) => p.status == 'approved').toList();
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        appCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: const [
          Text('လက်တွဲဖော်ရှာရန်', style: title),
          SizedBox(height: 8),
          Text('V1 မှာ Search UI ပုံစံပြထားပါတယ်။ Online version မှာ Country, City, Looking For, Age filter တကယ်အလုပ်လုပ်မယ်။'),
        ])),
        ...approved.map(profileCard),
      ],
    );
  }

  Widget postPage() {
    final name = TextEditingController();
    final age = TextEditingController();
    final country = TextEditingController();
    final city = TextEditingController();
    final job = TextEditingController();
    final hobby = TextEditingController();
    final facebook = TextEditingController();
    final telegram = TextEditingController();
    final phone = TextEditingController();

    String gender = 'ကျား';
    String lookingFor = 'မ';
    String goal = 'လက်ထပ်ရန်';
    String about = '';
    String partner = '';

    return StatefulBuilder(builder: (context, setLocal) {
      void generate() {
        genCount++;
        final openings = ['မင်္ဂလာပါ။', 'ကျွန်တော်/ကျွန်မအကြောင်းကို ရိုးရိုးလေး မိတ်ဆက်ချင်ပါတယ်။', 'ဘဝကို ရိုးသားတည်ငြိမ်စွာ ဖြတ်သန်းချင်သူတစ်ယောက်ပါ။'];
        final tones = ['ရိုးသားမှု၊ ယုံကြည်မှုနဲ့ အပြန်အလှန်လေးစားမှုကို အရေးကြီးတယ်လို့ ယုံကြည်ပါတယ်။', 'စကားပြောဆိုရာမှာ နားလည်မှုပေးနိုင်တာနဲ့ တာဝန်ယူတတ်တာကို တန်ဖိုးထားပါတယ်။', 'မိသားစုအပေါ် တာဝန်သိပြီး ဘဝကို အတူတကွ တည်ဆောက်ချင်တဲ့စိတ်ရှိပါတယ်။'];
        final o = openings[genCount % openings.length];
        final t = tones[genCount % tones.length];
        setLocal(() {
          about = '$o ${name.text} ဖြစ်ပြီး အသက် ${age.text} နှစ်၊ ${country.text} ${city.text} မှာ နေထိုင်ပါတယ်။ ${job.text.isEmpty ? "အလုပ်အကိုင်တစ်ခု" : job.text} အဖြစ် လုပ်ကိုင်နေပြီး ${hobby.text.isEmpty ? "အေးအေးဆေးဆေးနေထိုင်ခြင်း" : hobby.text} ကို စိတ်ဝင်စားပါတယ်။ $t $goal ရည်ရွယ်ချက်နဲ့ စစ်မှန်တဲ့ ဆက်ဆံရေးတစ်ခုကို တည်ဆောက်ချင်ပါတယ်။';
          partner = 'လိုချင်တဲ့ လက်တွဲဖော်က $lookingFor ဖြစ်ပြီး ရိုးသားမှုရှိသူ၊ စကားပြောရာမှာ ပွင့်လင်းသူ၊ အပြန်အလှန်လေးစားတတ်သူ ဖြစ်စေချင်ပါတယ်။ $goal ကို အလေးအနက်ထားသူဖြစ်ရင် ပိုကောင်းပါတယ်။ မိသားစုကို တန်ဖိုးထားပြီး တစ်ယောက်နဲ့တစ်ယောက် အားပေးကူညီနိုင်တဲ့သူကို ရှာဖွေနေပါတယ်။';
        });
      }

      return ListView(
        padding: const EdgeInsets.all(16),
        children: [
          appCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Profile တင်ရန်', style: title),
            field('အမည်', name),
            field('အသက်', age, keyboard: TextInputType.number),
            field('နိုင်ငံ', country),
            field('မြို့', city),
            dropdown('မိမိဖော်ပြလိုသော အမျိုးအစား', gender, ['ကျား','မ','LGBTQ+','အခြား','မဖော်ပြလိုပါ'], (v) => setLocal(() => gender = v!)),
            dropdown('မိမိရှာဖွေလိုသူ', lookingFor, ['မ','ကျား','LGBTQ+','အားလုံး','အခြား'], (v) => setLocal(() => lookingFor = v!)),
            dropdown('ရည်ရွယ်ချက်', goal, ['လက်ထပ်ရန်','အလေးအနက်တွဲရန်','မိတ်ဆွေဖြစ်ရန်'], (v) => setLocal(() => goal = v!)),
            field('အလုပ်အကိုင်', job),
            field('ဝါသနာ + ကိုယ်ရည်ကိုယ်သွေး', hobby),
            const Divider(),
            const Text('Admin ပဲ မြင်ရမည့် Contact အချက်အလက်', style: section),
            field('Facebook Link', facebook),
            field('Telegram Username', telegram),
            field('Viber / Phone', phone),
            const SizedBox(height: 10),
            FilledButton(onPressed: generate, child: const Text('Profile စာသားဖန်တီးမည်')),
            if (about.isNotEmpty) ...[
              const SizedBox(height: 12),
              const Text('ကိုယ့်အကြောင်း', style: section),
              Text(about),
              const SizedBox(height: 12),
              const Text('လိုချင်တဲ့ လက်တွဲဖော်', style: section),
              Text(partner),
            ],
            const SizedBox(height: 12),
            FilledButton.tonal(
              onPressed: () {
                if (about.isEmpty) generate();
                setState(() {
                  profiles.add(Profile(
                    id: 'CCYK-${1000 + Random().nextInt(9000)}',
                    name: name.text.isEmpty ? 'အမည်မရှိ' : name.text,
                    age: int.tryParse(age.text) ?? 18,
                    country: country.text,
                    city: city.text,
                    gender: gender,
                    lookingFor: lookingFor,
                    goal: goal,
                    job: job.text,
                    hobby: hobby.text,
                    about: about,
                    partner: partner,
                    facebook: facebook.text,
                    telegram: telegram.text,
                    phone: phone.text,
                  ));
                  tab = 0;
                });
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Profile တင်ပြီးပါပြီ။ Admin Approve စောင့်ပါ။')));
              },
              child: const Text('Profile တင်မည်'),
            )
          ])),
        ],
      );
    });
  }

  Widget adminPage() {
    if (!isAdmin) return const Center(child: Text('Admin only'));
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        appCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Admin', style: title),
          TextButton(onPressed: () => setState(() { isAdmin = false; tab = 0; }), child: const Text('Admin ထွက်မည်')),
          ...profiles.map((p) => appCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            profileTop(p),
            const SizedBox(height: 8),
            Text('Facebook: ${p.facebook.isEmpty ? "-" : p.facebook}'),
            Text('Telegram: ${p.telegram.isEmpty ? "-" : p.telegram}'),
            Text('Phone: ${p.phone.isEmpty ? "-" : p.phone}'),
            Wrap(spacing: 8, children: [
              FilledButton(onPressed: () => setState(() => p.status='approved'), child: const Text('Approve')),
              OutlinedButton(onPressed: () => setState(() => p.status='rejected'), child: const Text('Reject')),
            ])
          ]))),
        ])),
      ],
    );
  }

  Widget profileCard(Profile p) => appCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    profileTop(p),
    const Divider(),
    const Text('ကိုယ့်အကြောင်း', style: section),
    Text(p.about),
    const SizedBox(height: 10),
    const Text('လိုချင်တဲ့ လက်တွဲဖော်', style: section),
    Text(p.partner),
    const SizedBox(height: 12),
    FilledButton(
      onPressed: () => paymentDialog(p),
      child: const Text('Contact ရယူရန်'),
    )
  ]));

  Widget profileTop(Profile p) => Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Container(width: 76, height: 76, decoration: BoxDecoration(borderRadius: BorderRadius.circular(22), gradient: const LinearGradient(colors: [Color(0xFFBDEEFF), Color(0xFFFFE1EE)])), child: const Icon(Icons.person, size: 40)),
    const SizedBox(width: 13),
    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(p.name, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
      Text('ID: ${p.id} • ${p.age} နှစ် • ${p.gender}\n${p.city}, ${p.country} • ${p.job}', style: TextStyle(color: Colors.grey[700])),
      Wrap(spacing: 5, children: [
        Chip(label: Text(p.status == 'approved' ? 'Admin Approved' : p.status)),
        Chip(label: Text('ရှာဖွေလိုသူ: ${p.lookingFor}')),
      ])
    ]))
  ]);

  void paymentDialog(Profile p) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Contact Request တင်ရန်'),
        content: const Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Contact ရယူရန် ၁၀,၀၀၀ ကျပ် ပေးချေရပါမည်။'),
          SizedBox(height: 10),
          Text('Wave Pay / AYA Pay'),
          Text('+959750005038'),
          Text('Han Nay Oo'),
          SizedBox(height: 10),
          Text('ငွေလွှဲ Screenshot ကို Online Version မှာ Upload လုပ်နိုင်ပါမယ်။'),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('ပိတ်မည်')),
          FilledButton(onPressed: () {
            setState(() {
              requests.add('${p.name} contact request');
              p.views++;
            });
            Navigator.pop(context);
          }, child: const Text('Request ပို့မည်')),
        ],
      ),
    );
  }

  Widget appCard({required Widget child}) => Card(
    elevation: 0,
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
    child: Padding(padding: const EdgeInsets.all(18), child: child),
  );

  Widget field(String label, TextEditingController c, {TextInputType? keyboard}) => Padding(
    padding: const EdgeInsets.only(bottom: 10),
    child: TextField(controller: c, keyboardType: keyboard, decoration: InputDecoration(labelText: label, border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)))),
  );

  Widget dropdown(String label, String value, List<String> items, void Function(String?) onChanged) => Padding(
    padding: const EdgeInsets.only(bottom: 10),
    child: DropdownButtonFormField<String>(
      value: value,
      items: items.map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
      onChanged: onChanged,
      decoration: InputDecoration(labelText: label, border: OutlineInputBorder(borderRadius: BorderRadius.circular(16))),
    ),
  );
}

const title = TextStyle(fontSize: 24, fontWeight: FontWeight.w900);
const section = TextStyle(fontSize: 17, fontWeight: FontWeight.w900);

class LogoPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final blue = Paint()..shader = const LinearGradient(colors: [Color(0xFF25B9F2), Color(0xFF0F7FC7)]).createShader(Rect.fromLTWH(0,0,size.width,size.height));
    final pink = Paint()..shader = const LinearGradient(colors: [Color(0xFFFF5C8A), Color(0xFFE91E63)]).createShader(Rect.fromLTWH(0,0,size.width,size.height));
    final wave = Paint()
      ..shader = const LinearGradient(colors: [Color(0xFF25B9F2), Color(0xFFFF5C8A), Color(0xFFE91E63)]).createShader(Rect.fromLTWH(0,0,size.width,size.height))
      ..style = PaintingStyle.stroke
      ..strokeWidth = 5
      ..strokeCap = StrokeCap.round;

    Path left = Path()
      ..moveTo(size.width*.28, size.height*.20)
      ..cubicTo(size.width*.08, -8, -4, size.height*.30, size.width*.12, size.height*.62)
      ..cubicTo(size.width*.20, size.height*.82, size.width*.32, size.height*.92, size.width*.40, size.height*.98)
      ..cubicTo(size.width*.50, size.height*.78, size.width*.55, size.height*.48, size.width*.40, size.height*.24)
      ..cubicTo(size.width*.36, size.height*.18, size.width*.32, size.height*.17, size.width*.28, size.height*.20);
    canvas.drawPath(left, blue);

    Path right = Path()
      ..moveTo(size.width*.72, size.height*.20)
      ..cubicTo(size.width*.92, -8, size.width+4, size.height*.30, size.width*.88, size.height*.62)
      ..cubicTo(size.width*.80, size.height*.82, size.width*.68, size.height*.92, size.width*.60, size.height*.98)
      ..cubicTo(size.width*.50, size.height*.78, size.width*.45, size.height*.48, size.width*.60, size.height*.24)
      ..cubicTo(size.width*.64, size.height*.18, size.width*.68, size.height*.17, size.width*.72, size.height*.20);
    canvas.drawPath(right, pink);

    for (double y in [.42, .55]) {
      final p = Path()
        ..moveTo(size.width*.30, size.height*y)
        ..cubicTo(size.width*.42, size.height*(y-.18), size.width*.48, size.height*(y+.18), size.width*.58, size.height*y)
        ..cubicTo(size.width*.68, size.height*(y-.15), size.width*.76, size.height*y, size.width*.84, size.height*(y-.12));
      canvas.drawPath(p, wave);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
